//Code for Mini Calculator program in Java
package Lecture5;
import java.util.Scanner; //Scanner class has methods we can use

public class Calculator{
    public static void main(String[] args) {
        //Creating an object of the Scanner class
        Scanner scanner  = new Scanner(System.in);

        //Dropping a message on the screen
        System.out.println("🧮 Welcome to Mini Java Calculator 🧮");

        //Since we need to stop only when the user wants to stop we will need
        // an infinite while loop and at the same time counting the total number of valid calculations

        //Declaring variables that will come in handy
        double firstNumber, secondNumber;
        double resultNumber = 0.0;
        boolean isValiOperation = true;
        int validOperations = 0;
        char operatorNumber;
        boolean wannaContinue = true; // as far it is true we will keep taking inputs

        //Running an infinite while loop as far as the condition holds true
        while(wannaContinue){
            System.out.print("Enter the first number 🤓: ");
            firstNumber = scanner.nextDouble();

            //Clearing the input buffer
            scanner.nextLine();


            System.out.print("Enter the operator(+,-,*,/,%,^): ");
            operatorNumber = scanner.nextLine().charAt(0);

            System.out.print("Enter the second number 🤓: ");
            secondNumber = scanner.nextDouble();

            //Running some switch case checks then performing the operation
            switch(operatorNumber){
                case '+' ->{
                    resultNumber = firstNumber + secondNumber;
                    validOperations +=1;
                }

                case '-' ->{
                    resultNumber = firstNumber - secondNumber;
                    validOperations +=1;
                }

                case '*' ->{
                    resultNumber = firstNumber * secondNumber;
                    validOperations +=1;
                }

                case '/' ->{
                    //We will check if the divisor is 0 or not
                    if(secondNumber == 0){
                        System.out.print("\nSorry we cannot divide by zeroooo!😴");
                        isValiOperation = false;
                    }
                    else{
                        resultNumber = firstNumber / secondNumber;
                        validOperations +=1;
                    }
                }

                case '%' ->{
                    if(secondNumber == 0){
                        System.out.println("\nSorry we cannot divide by zerooo!");
                        isValiOperation = false;
                    }
                    else{
                        resultNumber = firstNumber % secondNumber;
                        validOperations +=1;
                    }
                }

                case '^' ->{
                    resultNumber = Math.pow(firstNumber , secondNumber);
                    validOperations +=1;
                }

                default -> {
                    System.out.println("\n Sorry invalid operator 👎🏼");
                    isValiOperation = false;
                }

            }

            if(isValiOperation){
                System.out.printf("😀 The answer is %.2f" ,resultNumber);
            }

            //Asking the user if they wanna continue or not
            System.out.print("\n\nWould you like to continue (Press 1 or else) 🤔:");
            int contint = scanner.nextInt();
            if(contint != 1){
                wannaContinue = false;
            }


        }

        System.out.println("\n✨✨Dear user , thanks for using our program!");
        System.out.printf("🫡Total number of valid calculations done by you was  %d❕",validOperations);


        scanner.close();

    }
}